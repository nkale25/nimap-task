package com.nimap.servicesImpl;

import java.io.IOException;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.nimap.dto.CategoryResponse;
import com.nimap.dto.ProductRequest;
import com.nimap.dto.ProductResponse;
import com.nimap.entities.CategoryEntity;
import com.nimap.entities.ProductEntity;
import com.nimap.repositories.CategoryRepository;
import com.nimap.repositories.ProductRepository;
import com.nimap.services.ProductService;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepository productRepo;

	@Autowired
	private CategoryRepository categoryRepo;

	@Override
	public ProductResponse createProduct(ProductRequest request, Long categoryId) throws IOException {
		CategoryEntity category = categoryRepo.findById(request.getCategoryId())
				.orElseThrow(() -> new RuntimeException("Category not found with ID: " + request.getCategoryId()));

		ProductEntity entity = convertRequestToEntity(request);
		entity.setCategory(category); // Associate category with the product

		ProductEntity savedProduct = productRepo.save(entity);
		return convertEntityToResponse(savedProduct);
	}

	@Override
	public ProductResponse getProductById(Long id) {

		if (Objects.nonNull(id)) {
			ProductEntity entity = productRepo.findById(id)
					.orElseThrow(() -> new RuntimeException("Product is not found..."));
			ProductResponse response = convertEntityToResponse(entity);
			return response;
		} else {
			throw new RuntimeException("Product id should not be null...!!!");
		}
	}

	@Override
	public ProductResponse updateProduct(ProductRequest request, Long id) {
		if (Objects.nonNull(id)) {
			ProductEntity entity = productRepo.findById(id)
					.orElseThrow(() -> new RuntimeException("Product is not found...."));

			CategoryEntity category = categoryRepo.findById(request.getCategoryId())
					.orElseThrow(() -> new RuntimeException("Category not found with ID: "));

			entity.setProductName(request.getProductName());
			entity.setProductPrice(request.getProductPrice());
			entity.setCategory(category);
			ProductEntity save = productRepo.save(entity);
			ProductResponse response = convertEntityToResponse(save);
			return response;
		} else {
			throw new RuntimeException("Product is not updated...!!!");
		}
	}

	@Override
	public String deleteProduct(Long id) {
		if (Objects.nonNull(id)) {
			ProductEntity entity = productRepo.findById(id)
					.orElseThrow(() -> new RuntimeException("Product is not found...."));
			productRepo.delete(entity);
			return "Product is deleted...";
		} else {
			throw new RuntimeException("Product is not deleted...!!!");
		}
	}

	@Override
	public Page<ProductResponse> getAllProducts(org.springframework.data.domain.Pageable pageable) {
		Page<ProductEntity> productPage = productRepo.findAll(pageable);
		return productPage.map(this::convertEntityToResponse);
	}
	
	private ProductEntity convertRequestToEntity(ProductRequest request) {
		ProductEntity entity = new ProductEntity();
		entity.setProductName(request.getProductName());
		entity.setProductPrice(request.getProductPrice());
		return entity;
	}

	private ProductResponse convertEntityToResponse(ProductEntity entity) {
		ProductResponse res = new ProductResponse();
		res.setId(entity.getId());
		res.setProductName(entity.getProductName());
		res.setProductPrice(entity.getProductPrice());
		CategoryEntity categoryEntity = entity.getCategory();
		CategoryResponse categoryResponse = convertEntityToResponse(categoryEntity);
		res.setCategory(categoryResponse);
		return res;
	}

	private CategoryResponse convertEntityToResponse(CategoryEntity entity) {
		CategoryResponse res = new CategoryResponse();
		res.setId(entity.getId());
		res.setCategoryName(entity.getCategoryName());
		return res;
	}


}
