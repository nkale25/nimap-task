package com.nimap.servicesImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.nimap.dto.CategoryRequest;
import com.nimap.dto.CategoryResponse;
import com.nimap.dto.ProductResponse;
import com.nimap.entities.CategoryEntity;
import com.nimap.entities.ProductEntity;
import com.nimap.repositories.CategoryRepository;
import com.nimap.services.CategoryService;

@Service
public class CategoryServiceImpl implements CategoryService {

	@Autowired
	private CategoryRepository repo;

	@Override
	public CategoryResponse createCategory(CategoryRequest request) {
		CategoryEntity entity = convertRequestToEntity(request);
		CategoryEntity save = repo.save(entity);
		CategoryResponse response = convertEntityToResponse(save);
		return response;
	}

	@Override
	public CategoryResponse getCategoryById(Long id) {

		if (Objects.nonNull(id)) {
			CategoryEntity entity = repo.findById(id)
					.orElseThrow(() -> new RuntimeException("Category is not found...."));
			CategoryResponse response = convertEntityToResponse(entity);
			return response;
		} else {
			throw new RuntimeException("Category id should not be null...!!!");
		}
	}

	@Override
	public CategoryResponse updateCategory(CategoryRequest request, Long id) {
		if (Objects.nonNull(id)) {
			CategoryEntity entity = repo.findById(id)
					.orElseThrow(() -> new RuntimeException("Category is not found...."));
			entity.setCategoryName(request.getCategoryName());
			CategoryEntity save = repo.save(entity);
			CategoryResponse response = convertEntityToResponse(save);
			return response;
		} else {
			throw new RuntimeException("Category is not updated...!!!");
		}
	}

	@Override
	public String deleteCategory(Long id) {
		if (Objects.nonNull(id)) {
			CategoryEntity entity = repo.findById(id)
					.orElseThrow(() -> new RuntimeException("Category is not found...."));
			repo.delete(entity);
			return "Category is deleted...";
		} else {
			throw new RuntimeException("Category is not deleted...!!!");
		}
	}

	@Override
	public Page<CategoryResponse> getAllCategories(Pageable pageable) {
		Page<CategoryEntity> categoryPage = repo.findAll(pageable);
		return categoryPage.map(this::convertEntityToResponse);
	}

	private CategoryEntity convertRequestToEntity(CategoryRequest request) {
		CategoryEntity entity = new CategoryEntity();
		entity.setCategoryName(request.getCategoryName());
		return entity;
	}

	private CategoryResponse convertEntityToResponse(CategoryEntity entity) {
		CategoryResponse res = new CategoryResponse();
		res.setId(entity.getId());
		res.setCategoryName(entity.getCategoryName());
		List<ProductEntity> products = entity.getProducts();

		List<ProductResponse> productResponse = new ArrayList<>();
		for (ProductEntity productEntity : products) {

			ProductResponse productResponse2 = convertEntityToResponse(productEntity);
			productResponse.add(productResponse2);
		}
		res.setProducts(productResponse);
		return res;

	}

	private ProductResponse convertEntityToResponse(ProductEntity entity) {
		ProductResponse res = new ProductResponse();
		res.setId(entity.getId());
		res.setProductName(entity.getProductName());
		res.setProductPrice(entity.getProductPrice());
		return res;
	}

}
