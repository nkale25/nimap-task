package com.nimap.services;

import java.io.IOException;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.nimap.dto.ProductRequest;
import com.nimap.dto.ProductResponse;

public interface ProductService {

	ProductResponse createProduct(ProductRequest request, Long categoryId) throws IOException;

	ProductResponse getProductById(Long id);

	ProductResponse updateProduct(ProductRequest request, Long id);

	String deleteProduct(Long id);

	Page<ProductResponse> getAllProducts(Pageable pageable);
}
