package com.nimap.services;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.nimap.dto.CategoryRequest;
import com.nimap.dto.CategoryResponse;

public interface CategoryService {

	CategoryResponse createCategory(CategoryRequest request);

	CategoryResponse getCategoryById(Long id);

	CategoryResponse updateCategory(CategoryRequest request, Long id);

	String deleteCategory(Long id);

	Page<CategoryResponse> getAllCategories(Pageable pageable);

}
