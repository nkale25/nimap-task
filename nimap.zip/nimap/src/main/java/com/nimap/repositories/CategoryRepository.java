package com.nimap.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nimap.entities.CategoryEntity;

public interface CategoryRepository extends JpaRepository<CategoryEntity, Long> {

}
