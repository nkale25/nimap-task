package com.nimap.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CategoryResponse {

	private Long id;

	private String categoryName;

	private List<ProductResponse> products;
}
